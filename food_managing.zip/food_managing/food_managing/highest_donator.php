<?php
include("login.php"); 
if($_SESSION['name']==''){
    header("location: signin.php");
}

// Database connection
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'food_managing');

if(isset($_POST['submit'])) {
    // Your form submission logic here

    // Assuming you insert the donation into the database here

    // Redirect to delivery.html after form submission
    header("location:delivery.html");
}

// Fetching the name of the highest donator
$query = "SELECT name FROM food_donations GROUP BY name ORDER BY COUNT(*) DESC LIMIT 1";
$result = mysqli_query($connection, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $highest_donator_name = $row['name'];
} else {
    $highest_donator_name = "No donations found.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Donate</title>
    <link rel="stylesheet" href="loginstyle.css">
</head>
<body style="background-color: #06C167;">
    <div class="container">
        <div class="regformf">
            <form action="" method="post">
                <p class="logo">Food <b style="color: #06C167;">Donate</b></p>
                <!-- Your form fields here -->

                <!-- Display the name of the highest donator -->
                <p style="text-align: center;">Highest Donator: <?php echo $highest_donator_name; ?></p>

                <!-- Rest of your form -->
            </form>
        </div>
    </div>
</body>
</html>
